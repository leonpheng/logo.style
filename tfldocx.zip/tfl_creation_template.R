
library(officer)
library(rvest)
library(tidyverse)
library(dplyr)
library(flextable)
source("lhofficer_working.R")

#library(lhtool2) 
#source("appendix_working.R")

################DEMO 1 GENE-PMX-MOSUNE-4904##############
## SECTION 0
toc=T # 
save_doc = "demo1.docx" #
#########################SECTION 1: Main Heading 1, TFL Heading 2####################################
###############WEIGHT VALIDATION#############
page_orient="landscape"
start_section=1#
main_tfl_title="Sensitivity Analysis of Final PK Mdel - Body Size Descriptors and Scaling Exponent"
heading_main<-"heading 1" #
get_file_list("./") # 
file_list=sort(get_file_list("./"))#

p="C:/Users/lpheng/Certara/GENE-PMX-MOSUNE-4904 - Project Data/Deliverables/Analysis/ER/1_EDA/ER_EDA_Eff_Mosune_V10/"
f="SummContVar.html"
file_list=list(html=paste0(p,f))
prev_html(1,1)

tfl_title=list(html="test")
footnote=list(html="test")
figure_height=list(html=0)
heading_tfl<-"heading 2"#

bold<-c("Age (years)","Weight (kg)","Sqrt. of Tumor SPD (mm)",
        "Anti-CD20 Level (ng/mL)","Albumin (g/L)","LDH (U/L)",
        "Nat. Log of LDH (ref: 1 U/L)","B-Cell count (1/Î¼L)",
        "T-Cell count (1/Î¼L)")
cell1<-c("Covariate at Baseline")

pat1<-c("[Min, Max]","Mean(SD, CV%)","Geo.Mean (Geo. CV)")
by_pat1<-c("[Minimum, Maximum]","Mean (SD, CV%)","Geometric Mean\n (Geometric CV%)")

shadcol="#D3D3D3"

header_rows=1:2
shade_col="#D3D3D3"
column1=c("Age (years)",                 
          "Weight (kg)","Sqrt. of Tumor SPD (mm)",     
          "Anti-CD20 Level (ng/mL)","Albumin (g/L)",               
          "LDH (U/L)","Nat. Log of LDH (ref: 1 U/L)",
          "B-Cell count (1/Î¼L)","T-Cell count (1/Î¼L)","NLR")
colnumber=1
col="red"
value2=c("64.4","62.9 (20.8)")

table_setting_list_tutorial()

set1="ft|>bg(i=header_rows,bg=shade_col,part=header)|> #header background setting
bold(i=header_rows,part=header)|> #header bold setting
border_inner_v()|> #add inner vertical line
border_inner_h()|> #add inner horizontal header setting
border_outer(part =body)|> #add outer lines header setting
hline_top()|> #add top line
hline_bottom()|> #add bottom line header setting
bold(i=~a%in%selected_bold_item)#"

format<-c(
"repl_colum(colno=1,pattern=pat1,value=by_pat1)",
#
#"repl_colum(colname=1,value=col1)", #ex: replace column 1 by values in col1
#"repl_colum(colname=2,value=col2)", #ex: replace column 2 by values in col2 
"repl_row(rowNo=1,colno=1,value=cell1)",
"reformat(header_rows=1,
shade_col=shadcol,
table_setting_list=set1,
fancy=2)")
table_format<-list(html=format)
#test<-prev_html(1,1,"csv")
prev_html(1,1)
prev_html_format(1,1)

t1<-delete_part(t1,part="header")
doc<-end_section() # 



################DEMO 2 PTC##############
#####SECTION 1: Main Heading 1, TFL Heading 2#################################
## SECTION 0
toc=T # 
save_doc = "demo2.docx" #
page_orient="landscape"

start_section=1#
main_tfl_title="Sensitivity Analysis of Final PK Mdel - Body Size Descriptors and Scaling Exponent"
heading_main<-"heading 1" #


tab=c("typical_values.html")
gof=c("GOFoverall_GT90.png","GOFoverall_LT90.png","scatter_dem1.png")
vpc=c("BH4 overall_byWTcat_lin.png","BH4 overall_byWTcat_log.png")

fixwt="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/B3_FINAL/"
fixwtvpc="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/vpc_WT_alloFix/"
estwt="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/WT_alloEstim/"
estwtvpc="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/vpc_WT_alloEstim/"
estlbw="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/LBW_alloEstim1/"
estlbwvpc="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/vpc_LBW_alloEstim1/"
estibw="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/IBW_alloEstim2/"
estibwvpc="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/vpc_IBW_alloEstim2/"
estajw="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/AJBW_alloEstim3/"
estajwvpc="../../../Analysis/PK_modeling/5_OPTIM_WEIGHT/vpc_AJBW_alloEstim3/"

file_list=list(html=c(paste0(c(fixwt,estwt,estlbw,estibw,estajw),tab)),
               png=paste0(rep(c(fixwt,estwt,estlbw,estibw,estajw),each=3),gof),
               vpc=paste0(rep(c(fixwtvpc,estwtvpc,estlbwvpc,estibwvpc,estajwvpc),each=2),vpc))
table_format<-NULL


model=c("Total Body Weight - Fixed","Total Body Weight - Estimated","Lean Body Weight","Ideal Body Weight","Adjusted Body Weight")
titvpc=c("Visual Predictive Checks - Linear Scale","Visual Predictive Checks - Semi-Log Scale")        

tfl_title=list(c(paste0("Typical Values of Final Model - ",model)),
               paste0(c("BH4 Goodness-of-Fit Plots - <90 kg ",paste("BH4 Goodness-of-Fit Plots - ",uc("gte"),"90 kg "),
                        "Baseline Demographic vs Random Effects of BH4 PK Parameters "),rep(model,each=3)),
               paste0(titvpc," - ",rep(model,each=2))) # see  tutorial for tips
footnote=list(
  html=c(rep("ALB= albumin (g/L); BH4= 5,6,7,8-tetrahydrobiopterin; CI= confidence interval; CL/F=apparent systemic clearance; IIV= inter-individual variability; RSE= relative standard error; Vc/F=apparent central volume of distribution; ; Ω= variance of Vc/F (ΩVc/F), 
  Frel (ΩFrel) or BH4 baseline (Ωbaseline). *: 202 out of 1000 runs with minimization terminated were skipped when calculating the bootstrap results",5)),
  png=c(rep(c("BH4= 5,6,7,8-tetrahydrobiopterin; LOESS=locally weighted scatter plot smoothing; TAD= time after last dose",
            "BH4= 5,6,7,8-tetrahydrobiopterin; LOESS=locally weighted scatter plot smoothing; TAD= time after last dose",
            "AJBW= adjusted body weight; AGE= age (years); BH4= 5,6,7,8-tetrahydrobiopterin; BMI= body mass index (kg/m2); 
    HT= height (cm); nBSL= random effects of baseline BH4 levels; IBW= ideal body weight (kg);
    LBW= lean body weight (kg);
    nFrel = random effects of relative fraction of absorption/biotransformation; nVc= random effects of apparent central volume of distribution; 
    p= p-value; r= Pearson correlation coefficient; WT= total weight (kg).")
            ,5)),
  vpc=c(rep("BH4= 5,6,7,8-tetrahydrobiopterin; CI= confidence interval. Note 1: for legibility, VPC concentrations at time after dose (TAD) greater than 100 h were not displayed.",10)))
  
heading_tfl<-"heading 2"#
figure_height=list(html=0,png=5,vpc=5)
table_format<-NULL
#rep(5,length(unlist(footnote))) # 
doc<-end_section() # 


#########################SECTION 2: Main Heading 1 no TFL (place holder)####################################
page_orient="landscape"
start_section="placeholder"#use string or txt if section 1 alredy define. Use 1 and file_list=NULL if it's section 1
heading_main<-"heading 1" #
main_tfl_title="Monte-Carlo Simulations Monte Carlo Simulations - 30 mg/kg BID"
file_list=NULL
doc<-end_section() # 

#########################SECTION 2.1: Main Heading 2, TFL Heading 3, Combined Items####################################

########################BID MC SIMULATION##################
page_orient="landscape"
start_section=2#
main_tfl_title="PK vs PD Time Profile Under Steady State"
heading_main<-"heading 2" #
get_file_list("../../../Analysis/PKPD_modeling/5_MC_simulation/output_BID") # 
file_list=sort(get_file_list("./"))#

adpk=c("time_pk_adult_agegrp_lin.png","time_pk_adult_agegrp_log.png",                           
       "time_pk_adult_asian_lin.png","time_pk_adult_asian_log.png",                            
       "time_pk_adult_classic_lin.png","time_pk_adult_classic_log.png"
    )

pedpk=c("time_pk_PED_agegrp_lin.png","time_pk_PED_agegrp_log.png",                             
        "time_pk_PED_asian_lin.png","time_pk_PED_asian_log.png",                              
        "time_pk_PED_classic_lin.png","time_pk_PED_classic_log.png") 

adpd=c("time_pd_adult_agegrp.png","time_pd_adult_asian.png",                                
       "time_pd_adult_classical.png",                                  
    "time_pd_adult_ucphe3.png")

pedpd=c("time_pd_PED_agegrp.png",
       "time_pd_PED_asian.png","time_pd_PED_classical.png",                              
        "time_pd_PED_ucphe3.png") 

fixwt="../../../Analysis/PKPD_modeling/5_MC_simulation/output_BID/"

file_list=list(adultpk=c(paste0(c(fixwt,fixwt),c(adpk))),
               pedpk=c(paste0(c(fixwt,fixwt),pedpk)),
               adultpd=c(paste0(c(fixwt),adpd)),
               pedpd=c(paste0(c(fixwt),pedpd)))

figure_height=list(adultpk=4,
                   pedpk=4,
                   adultpd=5,
                   pedpd=5) # 
table_format<-NULL
#prev_png(2,3) #to preview png file


a=c(paste0("Linear (left) and Semi-Log (right) (",uc("gte")," 2 years) – By Age Group"),"")
b=c(paste0("Linear (left) and Semi-Log (right) (",uc("gte")," 2 years) – By Ethnicity"),"")
c=c(paste0("Linear (left) and Semi-Log (right) (",uc("gte")," 2 years) – By Classical PKU"),"")
#cc=c(paste0("Linear (left) and Semi-Log (right) (",uc("gte")," 2 years) – By Uncontrolled Phe"),"","")

d=c("Linear (left) and Semi-Log (right) (< 2 years) – By Age Group","")
e=c("Linear (left) and Semi-Log (right) (< 2 years) – By Ethnicity","")
f=c("Linear (left) and Semi-Log (right) (< 2 years) – By Classical PKU","")
#ff=c("Linear (left) and Semi-Log (right) (< 2 years) –  By Uncontrolled Phe","","")

a1=c(paste0("PD vs Time Profile Under Steady State - ",uc("gte")," 2 years) – By Age Group"))
b1=c(paste0("PD vs Time Profile Under Steady State - ",uc("gte")," 2 years) – By Ethnicity"))
c1=c(paste0("PD vs Time Profile Under Steady State - ",uc("gte")," 2 years) – By Classical PKU"))
c2=c(paste0("PD vs Time Profile Under Steady State - ",uc("gte")," 2 years) – By Uncontrolled Phe"))

d1=c("PD vs Time Profile Under Steady State - < 2 years) – By Age Group")
e1=c("PD vs Time Profile Under Steady State - < 2 years) – By Ethnicity")
f1=c("PD vs Time Profile Under Steady State - < 2 years) – By Classical PKU")
f2=c("PD vs Time Profile Under Steady State - < 2 years) – By Uncontrolled Phe ")

#library(lhplot)

tfl_title=list(adultpk=c(a,b,c),pedpk=c(d,e,f),adultpd=c(a1,b1,c1,c2),pedpd=c(d1,e1,f1,f2)) # see tutorial for tips

ft="BH4= 5,6,7,8-tetrahydrobiopterin; PK= pharmacokinetic; PKU= phenylketonuria; BID= twice daily"
ft1="Phe=phenylalanine; PD= pharmacodynamic; BID= twice daily"
footnote=list(adultpk=rep(c("",ft),3),pedpk=rep(c("",ft),3),adultpd=c(rep(c(ft1),4)),pedpd=c(rep(c(ft1),4)))
heading_tfl<-"heading 3"#

doc<-end_section() # 

#########################SECTION 2.2: Main Heading 2, TFL Heading 3####################################
page_orient="landscape"
start_section=3#
main_tfl_title="PK Exposure Under Steady State (Day 50)"
heading_main<-"heading 2" #
get_file_list("../../../Analysis/PKPD_modeling/5_MC_simulation/output_BID") # 
file_list=sort(get_file_list("./"))#

adpk=c("stats_pk_dose_agegrp.html","stats_pk_dose_asian.html",                           
       "stats_pk_dose_classical.html")

pedpk=c("stats_pk_dose_agegrp_PED.html","stats_pk_dose_asian_PED.html" ,"stats_pk_dose_classical_PED.html" ) 

adpd=c("stats_pd_continuous_agegrp_OVERALL_subtotal_ADULT.html" ,
       "stats_pd_continuous_asian_OVERALL_subtotal_ADULT.html","stats_pd_continuous_classic_OVERALL_subtotal_ADULT.html",
       "stats_pd_continuous_sex_OVERALL_subtotal_ADULT.html" ,
       "stats_pd_continuous_ucphe3_OVERALL_subtotal_ADULT.html",
       "stats_pd_dose_agegrp_subtotal_ADULT.html" ,"stats_pd_dose_asian_subtotal_ADULT.html","stats_pd_dose_classic_subtotal_ADULT.html" ,
       "stats_pd_dose_sex_subtotal_ADULT.html" , "stats_pd_dose_ucphe3_subtotal_ADULT.html" )

pedpd=c("stats_pd_continuous_agegrp_OVERALL_subtotal_PED.html" , 
        "stats_pd_continuous_asian_OVERALL_subtotal_PED.html",     
        "stats_pd_continuous_classic_OVERALL_subtotal_PED.html",      
        "stats_pd_continuous_sex_OVERALL_subtotal_PED.html",      
        "stats_pd_continuous_ucphe3_OVERALL_subtotal_PED.html",
        "stats_pd_dose_agegrp_subtotal_PED.html",
        "stats_pd_dose_asian_subtotal_PED.html",                                
        "stats_pd_dose_classic_subtotal_PED.html" ,                
        "stats_pd_dose_sex_subtotal_PED.html" ,"stats_pd_dose_ucphe3_subtotal_PED.html" 
)
respk<-"Summary of PK Response"
respd<-"Summary of PD Response" 
respd1<-"Summary of Target Attainment"

a= c("By Age Group","By Ethnicity","By Classical PKU")
b= c("By Age Group","By Ethnicity","By Classical PKU", "By Sex","By Uncontrolled Phe")

set1<-paste0(respk," - ",paste0(uc("gte"),"2 years - "),a)
set2<-paste0(respk," - ",paste0("<","2 years - "),a)

set3<-paste0(respd," - ",paste0(uc("gte"),"2 years - "),b)
set4<-paste0(respd," - ",paste0("<","2 years - "),b)  
        
set5<-paste0(respd1," - ",paste0(uc("gte"),"2 years - "),b)
set6<-paste0(respd1," - ",paste0("<","2 years - "),b)  

c="BH4= 5,6,7,8-tetrahydrobiopterin; CL/F= apparent clearance; CV= coefficient of variability; N= number of subjects PI= percentile interval; PK= pharmacokinetic, Vc/F= apparent volume of distribution "
d="CV= coefficient of variability; Emax= maximum enhancement of Phe degradation; Kin= phenylalanine intake rate; N= number of subjects; Phe= phenylalanine; PI= percentile interval; PD= pharmacodynamic"
e="N= number of subjects PI= percentile interval; PD= pharmacodynamic; Phe= phenylalanine"

fixwt="../../../Analysis/PKPD_modeling/5_MC_simulation/output_BID/"

file_list=list(adultpk=c(paste0(c(fixwt,fixwt),c(adpk))),
               pedpk=c(paste0(c(fixwt,fixwt),pedpk)))#,
               #adultpd=c(paste0(c(fixwt),adpd)),
               #pedpd=c(paste0(c(fixwt),pedpd)))


####PRE VIEW TABLE and create list of values for replacing 
#prev_html(1,1)
#prev_html_format(2,1)

col1<-c("Parameter","Parameter",
        rep(paste0("AUC",uc("alfa")),2), #AUC with subscript alfa in bold
        rep(paste0("C",uc("gam")),2),
            rep(paste0("C",uc("gte")),2),
                rep(paste0("Baseline BH","4"),2)# C with subscript+italic min + post txt= just a test
) 
col2<-c(rep("Statistic",2),
        rep(c("Mean (CV%)",
        "Median [90%PI]"),4))

row1<-c(rep("30 mg/kg",4),"")
row2<-c("2-5 years","6-11 years","12-15 years",paste0(uc("gte"),"16 years"))
bold<-c("AUCss","Cmax.ss")

row1a<-c(rep("30 mg/kg",3),"")
row2a<-c("< 6 months","6 - < 12 months","12 - <24 months")

tbf1<-c(
   "repl_colum(colname=1,value=col1)", #ex: replace column 1 by values in col1
  "repl_colum(colname=2,value=col2)", #ex: replace column 2 by values in col2 
#  "repl_row(rowNo=1,colname=3:7,value=row1)", #ex: replace row 1 col 3:7 by values in row1
#  "repl_row(rowNo=2,colname=3:6,value=row2)", 
    "reformat(
    shade_merge_column_row=1:2,
    merge_row_colum=1:2,
    bold_rowNo=NULL,
    bold_colNo=1,
    bold_colupto=2:3,
    bold_var=bold)"#ex: shade_merge_column rows 1:2 merge_row_colums 1:2, select_bold column 1 on "AUCss","Cmax.ss"
)


tbf2<-c(
  "repl_colum(colname=1,value=col1)", #ex: replace column 1 by values in col1
  "repl_colum(colname=2,value=col2)", #ex: replace column 2 by values in col2 
 # "repl_row(rowNo=1,colname=3:6,value=row1a)", #ex: replace row 1 col 3:7 by values in row1
 # "repl_row(rowNo=2,colname=3:5,value=row2a)", 
  "reformat(
    shade_merge_column_row=1:2,
    merge_row_colum=1:2,
    bold_rowNo=NULL,
    bold_colNo=1,
    bold_colupto=2:3,
    bold_var=bold)"#ex: shade_merge_column rows 1:2 merge_row_colums 1:2, select_bold column 1 on "AUCss","Cmax.ss"
)

###List of settings, keep the order#####

#table_format=NULL
#table_format=list(adultpk=tbf1,
#                 pedpk=tbf2) # or NULL if no formatting required
table_format=NULL
tfl_title=list(adultpk=c(set1),pedpk=c(set2))#,adultpd=c(a1,b1,c1,c2),pedpd=c(d1,e1,f1,f2)) # see tutorial for tips
footnote=list(adultpk=rep(c,3),pedpk=rep(c,3))#,adultpd=c(rep(c(ft1),4)),pedpd=c(rep(c(ft1),4)))

heading_tfl<-"heading 3"#
figure_height=rep(5,length(unlist(footnote))) # 
doc<-end_section() # 


#########################SECTION 2.3: Main Heading 2, TFL Heading 3####################################
##SECTION 2 EX: Starting section is mandatory for creating next section. Set start_section = 1 
page_orient="landscape"
start_section=2#
main_tfl_title="PD Exposure Under Steady State (Day 50)"
heading_main<-"heading 2" #
get_file_list("../../../Analysis/PKPD_modeling/5_MC_simulation/output_BID") # 
file_list=sort(get_file_list("./"))#

adpk=c("stats_pk_dose_agegrp.html","stats_pk_dose_asian.html",                           
       "stats_pk_dose_classical.html")

pedpk=c("stats_pk_dose_agegrp_PED.html","stats_pk_dose_asian_PED.html" ,"stats_pk_dose_classical_PED.html" ) 

adpd=c("stats_pd_continuous_agegrp_OVERALL_subtotal_ADULT.html" ,
       "stats_pd_continuous_asian_OVERALL_subtotal_ADULT.html","stats_pd_continuous_classic_OVERALL_subtotal_ADULT.html",
       "stats_pd_continuous_sex_OVERALL_subtotal_ADULT.html" ,
       "stats_pd_continuous_ucphe3_OVERALL_subtotal_ADULT.html",
       "stats_pd_dose_agegrp_subtotal_ADULT.html" ,"stats_pd_dose_asian_subtotal_ADULT.html","stats_pd_dose_classic_subtotal_ADULT.html" ,
       "stats_pd_dose_sex_subtotal_ADULT.html" , "stats_pd_dose_ucphe3_subtotal_ADULT.html" )

pedpd=c("stats_pd_continuous_agegrp_OVERALL_subtotal_PED.html" , 
        "stats_pd_continuous_asian_OVERALL_subtotal_PED.html",     
        "stats_pd_continuous_classic_OVERALL_subtotal_PED.html",      
        "stats_pd_continuous_sex_OVERALL_subtotal_PED.html",      
        "stats_pd_continuous_ucphe3_OVERALL_subtotal_PED.html",
        "stats_pd_dose_agegrp_subtotal_PED.html",
        "stats_pd_dose_asian_subtotal_PED.html",                                
        "stats_pd_dose_classic_subtotal_PED.html" ,                
        "stats_pd_dose_sex_subtotal_PED.html" ,"stats_pd_dose_ucphe3_subtotal_PED.html" 
)
respk<-"Summary of PK Response"
respd<-"Summary of PD Response" 
respd1<-"Summary of Target Attainment"

a= c("By Age Group","By Ethnicity","By Classical PKU")
b= c("By Age Group","By Ethnicity","By Classical PKU", "By Sex","By Uncontrolled Phe")

set1<-paste0(respk," - ",paste0(uc("gte"),"2 years - "),a)
set2<-paste0(respk," - ",paste0("<","2 years - "),a)

set3<-paste0(respd," - ",paste0(uc("gte"),"2 years - "),b)
set4<-paste0(respd," - ",paste0("<","2 years - "),b)  

set5<-paste0(respd1," - ",paste0(uc("gte"),"2 years - "),b)
set6<-paste0(respd1," - ",paste0("<","2 years - "),b)  

c="BH4= 5,6,7,8-tetrahydrobiopterin; CL/F= apparent clearance; CV= coefficient of variability; N= number of subjects PI= percentile interval; PK= pharmacokinetic, Vc/F= apparent volume of distribution "
d="CV= coefficient of variability; Emax= maximum enhancement of Phe degradation; Kin= phenylalanine intake rate; N= number of subjects; Phe= phenylalanine; PI= percentile interval; PD= pharmacodynamic"
e="N= number of subjects PI= percentile interval; PD= pharmacodynamic; Phe= phenylalanine"

fixwt="../../../Analysis/PKPD_modeling/5_MC_simulation/output_BID/"

file_list=list(
  #adultpk=c(paste0(c(fixwt,fixwt),c(adpk))),
  #pedpk=c(paste0(c(fixwt,fixwt),pedpk)))#,
adultpd=c(paste0(c(fixwt),adpd)),
pedpd=c(paste0(c(fixwt),pedpd)))

figure_height=list(
  adultpd=0,
  pedpd=0) # 

library(lhplot)

tfl_title=list(
#adultpk=c(set1),pedpk=c(set2))#,
adultpd=c(set3,set4),pedpd=c(set5,set6)) # see tutorial for tips

footnote=list(
 # adultpk=rep(c,3),pedpk=rep(c,3))#,
adultpd=c(rep(c(d),5),rep(c(e),5)),pedpd=c(rep(c(d),5),rep(c(e),5)))

heading_tfl<-"heading 3"#
figure_height=rep(5,length(unlist(footnote))) # 
doc<-end_section() # 


#########################SECTION 3: Main Heading 1, no TFL (place holder)####################################

##SECTION 2 EX: Starting section is mandatory for creating next section. Set start_section = 1 
page_orient="landscape"
start_section="ph"# should be any character instead of numeric
heading_main<-"heading 1" #
main_tfl_title="Monte-Carlo Simulations Monte Carlo Simulations - Weight Adjusted and Flat Dose"
doc<-end_section() # 

#########################SECTION 3.1: Main Heading 2, TFL Heading 3####################################
##################################WT ADJUSTED DOSE vs FLAT DOSE################
##SECTION 2 EX: Starting section is mandatory for creating next section. Set start_section = 1 
page_orient="landscape"
start_section=4#
main_tfl_title="PK vs PD Time Profile Under Steady State"
heading_main<-"heading 2" #
get_file_list("../../../Analysis/PKPD_modeling/7_MC_in_adults/output/") # 
file_list=sort(get_file_list("./"))#

adpk=c("time_pk_adult_wtgr_lin.png","time_pk_adult_wtgr_log.png","time_pk_adult_asian_lin.png",            
       "time_pk_adult_asian_log.png","time_pk_adult_classic_lin.png","time_pk_adult_classic_log.png",          
       "time_pk_adult_sex_lin.png","time_pk_adult_sex_log.png"
)

adpd=c("time_pd_adult_wtgr.png","time_pd_adult_asian.png",
       "time_pd_adult_classical.png",
       "time_pd_adult_sex.png" ,                 
       "time_pd_adult_ucphe3.png"  )

fixwt="../../../Analysis/PKPD_modeling/7_MC_in_adults/output/"

file_list=list(adultpk=c(paste0(c(fixwt,fixwt),c(adpk))),
               #pedpk=c(paste0(c(fixwt,fixwt),pedpk)),
               adultpd=c(paste0(c(fixwt),adpd)))#,
               #pedpd=c(paste0(c(fixwt),pedpd)))
figure_height=list(adultpk=5,
                   #pedpk=c(paste0(c(fixwt,fixwt),pedpk)),
                   adultpd=5) # 


a=c(paste0("Linear (left) and Semi-Log (right) – By Age Group"),"")
b=c(paste0("Linear (left) and Semi-Log (right) – By Ethnicity"),"")
c=c(paste0("Linear (left) and Semi-Log (right) – By Classical PKU"),"")
d=c(paste0("Linear (left) and Semi-Log (right) – By Sex"),"")
#cc=c(paste0("Linear (left) and Semi-Log (right) (",uc("gte")," 2 years) – By Uncontrolled Phe"),"","")

#d=c("Linear (left) and Semi-Log (right) (< 2 years) – By Age Group","")
#e=c("Linear (left) and Semi-Log (right) (< 2 years) – By Ethnicity","")
#f=c("Linear (left) and Semi-Log (right) (< 2 years) – By Classical PKU","")
#ff=c("Linear (left) and Semi-Log (right) (< 2 years) –  By Uncontrolled Phe","","")

a1=c(paste0("PD vs Time Profile Under Steady State - By Age Group"))
b1=c(paste0("PD vs Time Profile Under Steady State - By Ethnicity"))
c1=c(paste0("PD vs Time Profile Under Steady State - By Classical PKU"))
c2=c(paste0("PD vs Time Profile Under Steady State - By Sex"))
c3=c(paste0("PD vs Time Profile Under Steady State - By Uncontrolled Phe"))

#d1=c("PD vs Time Profile Under Steady State - < 2 years) – By Age Group")
#e1=c("PD vs Time Profile Under Steady State - < 2 years) – By Ethnicity")
#f1=c("PD vs Time Profile Under Steady State - < 2 years) – By Classical PKU")
#f2=c("PD vs Time Profile Under Steady State - < 2 years) – By Uncontrolled Phe ")

#library(lhplot)

tfl_title=list(adultpk=c(a,b,c,d),
               #pedpk=c(d,e,f),
               adultpd=c(a1,b1,c1,c2,c3))
               #,pedpd=c(d1,e1,f1,f2)) # see tutorial for tips

ft="BH4= 5,6,7,8-tetrahydrobiopterin; PK= pharmacokinetic; PKU= phenylketonuria; QD= once daily"
ft1="Phe=phenylalanine; PD= pharmacodynamic; QD= once daily"

footnote=list(adultpk=rep(c("",ft),4),
              #pedpk=rep(c("",ft),3),
              adultpd=c(rep(c(ft1),5)))#,
              #pedpd=c(rep(c(ft1),4)))

heading_tfl<-"heading 3"#

doc<-end_section() # 

#########################SECTION 3.2: Main Heading 2, TFL Heading 3####################################
page_orient="landscape"
start_section=5#
main_tfl_title="PK Exposure Under Steady State (Day 50)"
heading_main<-"heading 2" #
get_file_list("../../../Analysis/PKPD_modeling/7_MC_in_adults/output/") # 
file_list=sort(get_file_list("./"))#

adpk=c("stats_pk_dose_wtgr.html","stats_pk_dose_asian.html",                           
       "stats_pk_dose_classic.html")
#pedpk=c("stats_pk_dose_agegrp_PED.html","stats_pk_dose_asian_PED.html" ,"stats_pk_dose_classical_PED.html" ) 

adpd=c("stats_PDcontinuous_dose_agegrp_PED.html" ,
       "stats_PDcontinuous_dose_asian.html","stats_PDcontinuous_dose_classical.html",
       #"stats_pd_continuous_sex_OVERALL_subtotal_ADULT.html" ,
       "stats_PDcontinuous_dose_ucphe3.html",
       "stats_pd_dose_agegrp.html" ,"stats_pd_dose_asian.html","stats_pd_dose_classic.html" ,
       #"stats_pd_dose_sex_subtotal_ADULT.html" , 
       "stats_pd_dose_ucphe3.html" )

#pedpd=c("stats_pd_continuous_agegrp_OVERALL_subtotal_PED.html" , 
#        "stats_pd_continuous_asian_OVERALL_subtotal_PED.html",     
#        "stats_pd_continuous_classic_OVERALL_subtotal_PED.html",      
#        "stats_pd_continuous_sex_OVERALL_subtotal_PED.html",      
#        "stats_pd_continuous_ucphe3_OVERALL_subtotal_PED.html",
#        "stats_pd_dose_agegrp_subtotal_PED.html",
#        "stats_pd_dose_asian_subtotal_PED.html",                                
#        "stats_pd_dose_classic_subtotal_PED.html" ,                
#        "stats_pd_dose_sex_subtotal_PED.html" ,"stats_pd_dose_ucphe3_subtotal_PED.html" 
#)

respk<-"Summary of PK Response"
respd<-"Summary of PD Response" 
respd1<-"Summary of Target Attainment"

a= c("By Age Group","By Ethnicity","By Classical PKU")
b= c("By Age Group","By Ethnicity","By Classical PKU", "By Uncontrolled Phe")

set1<-paste0(respk," - ",a)
#set2<-paste0(respk," - ",paste0("<","2 years - "),a)

set3<-paste0(respd," - ",b)
#set4<-paste0(respd," - ",paste0("<","2 years - "),b)  

set5<-paste0(respd1," - ",b)
#set6<-paste0(respd1," - ",paste0("<","2 years - "),b)  

c="BH4= 5,6,7,8-tetrahydrobiopterin; CL/F= apparent clearance; CV= coefficient of variability; N= number of subjects PI= percentile interval; PK= pharmacokinetic, Vc/F= apparent volume of distribution "
d="CV= coefficient of variability; Emax= maximum enhancement of Phe degradation; Kin= phenylalanine intake rate; N= number of subjects; Phe= phenylalanine; PI= percentile interval; PD= pharmacodynamic"
e="N= number of subjects PI= percentile interval; PD= pharmacodynamic; Phe= phenylalanine"

fixwt="../../../Analysis/PKPD_modeling/7_MC_in_adults/output/"

file_list=list(adultpk=c(paste0(c(fixwt),c(adpk))),
               pedpk=c(paste0(c(fixwt),adpd)))#,
#adultpd=c(paste0(c(fixwt),adpd)),
#pedpd=c(paste0(c(fixwt),pedpd)))

figure_height=list(adultpk=0,
                   pedpk=0) # 
#library(lhplot)

tfl_title=list(adultpk=c(set1),
               #pedpk=c(set2))#,
               adultpd=c(set3,set5))#,pedpd=c(d1,e1,f1,f2)) # see tutorial for tips

footnote=list(adultpk=rep(c,3),
              #pedpk=rep(c,3))#,
              adultpd=c(rep(c(d),4),rep(c(e),4)))#,pedpd=c(rep(c(ft1),4)))

heading_tfl<-"heading 3"#
doc<-end_section() # 
